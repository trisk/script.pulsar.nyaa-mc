# coding: utf-8
from pulsar import provider
from urllib import unquote_plus
import re

# this read the settings
url = provider.ADDON.getSetting('url_address')
icon = provider.ADDON.getAddonInfo('icon')
name_provider = provider.ADDON.getAddonInfo('name') # gets name
extra = provider.ADDON.getSetting('extra')
time_noti = int(provider.ADDON.getSetting('time_noti'))
values2 = {"ALL":'1_0',"English translations":'1_37',"Non English translations":'1_38' ,"Raw":'1_11'} # read category
category = values2[provider.ADDON.getSetting('category')]
TV_min_size = float(provider.ADDON.getSetting('TV_min_size'))
TV_max_size = float(provider.ADDON.getSetting('TV_max_size'))
max_magnets = int(provider.ADDON.getSetting('max_magnets'))  #max_magnets

#define quality variables
quality_allow = ['*'] 
quality_deny = []
query_key = ''
max_size = 10.00 #10 it is not limit
min_size = 0.00

#*******************************START common functions ****************************************
def movie_filtering():
	#quality_movie
	movie_qua1 = provider.ADDON.getSetting('movie_qua1') #480p
	movie_qua2 = provider.ADDON.getSetting('movie_qua2') #HDTV
	movie_qua3 = provider.ADDON.getSetting('movie_qua3') #720p
	movie_qua4 = provider.ADDON.getSetting('movie_qua4') #1080p
	movie_qua5 = provider.ADDON.getSetting('movie_qua5') #3D
	movie_qua6 = provider.ADDON.getSetting('movie_qua6') #CAM
	movie_qua7 = provider.ADDON.getSetting('movie_qua7') #TeleSync
	#Accept File
	movie_key_allowed = provider.ADDON.getSetting('movie_key_allowed').replace(', ',',').replace(' ,',',')
	movie_allow = re.split(',',movie_key_allowed)
	if movie_qua1 == 'Accept File': movie_allow.append('480p')
	if movie_qua2 == 'Accept File': movie_allow.append('HDTV')
	if movie_qua3 == 'Accept File': movie_allow.append('720p')
	if movie_qua4 == 'Accept File': movie_allow.append('1080p')  
	if movie_qua5 == 'Accept File': movie_allow.append('3D')
	if movie_qua6 == 'Accept File': movie_allow.append('CAM') 
	if movie_qua7 == 'Accept File': movie_allow.extend(['TeleSync', ' TS '])
	#Block File
	movie_key_denied = provider.ADDON.getSetting('movie_key_denied').replace(', ',',').replace(' ,',',')
	movie_deny = re.split(',',movie_key_denied)
	if movie_qua1 == 'Block File': movie_deny.append('480p')
	if movie_qua2 == 'Block File': movie_deny.append('HDTV')
	if movie_qua3 == 'Block File': movie_deny.append('720p')
	if movie_qua4 == 'Block File': movie_deny.append('1080p')  
	if movie_qua5 == 'Block File': movie_deny.append('3D')
	if movie_qua6 == 'Block File': movie_deny.append('CAM') 
	if movie_qua7 == 'Block File': movie_deny.extend(['TeleSync', ' TS '])
	if '' in movie_allow: movie_allow.remove('')
	if '' in movie_deny: movie_deny.remove('') 
	return movie_allow, movie_deny

def TV_filtering():
	#from main import provider
	#quality_TV
	TV_qua1 = provider.ADDON.getSetting('TV_qua1') #480p
	TV_qua2 = provider.ADDON.getSetting('TV_qua2') #HDTV
	TV_qua3 = provider.ADDON.getSetting('TV_qua3') #720p
	TV_qua4 = provider.ADDON.getSetting('TV_qua4') #1080p
	#Accept File
	TV_key_allowed = provider.ADDON.getSetting('TV_key_allowed').replace(', ',',').replace(' ,',',')
	TV_allow = re.split(',',TV_key_allowed)
	if TV_qua1 == 'Accept File': TV_allow.append('480p')
	if TV_qua2 == 'Accept File': TV_allow.append('HDTV')
	if TV_qua3 == 'Accept File': TV_allow.append('720p')
	if TV_qua4 == 'Accept File': TV_allow.append('1080p')
	#Block File
	TV_key_denied = provider.ADDON.getSetting('TV_key_denied').replace(', ',',').replace(' ,',',')
	TV_deny = re.split(',',TV_key_denied)
	if TV_qua1 == 'Block File': TV_deny.append('480p')
	if TV_qua2 == 'Block File': TV_deny.append('HDTV')
	if TV_qua3 == 'Block File': TV_deny.append('720p')
	if TV_qua4 == 'Block File': TV_deny.append('1080p')
	if '' in TV_allow: TV_allow.remove('')
	if '' in TV_deny: TV_deny.remove('') 
	return TV_allow, TV_deny

#normalize
def normalize(word):
	value = ''
	for a in word:
		if ord(a)< 128:
			value += chr(ord(a))
	value = value.replace('-',' ').replace('&ntilde;','')
	return value
	
# validate keywords
def included(value, keys):
	value = normalize(value)
	res = True
	if '*' not in keys:
		res1 = []
		for key in keys:
			res2 = []
			for item in re.split('\s', key):
				item = normalize(item)
				item = item.replace('?',' ')
				if item.upper() in value.upper():
					res2.append(True)
				else:
					res2.append(False)
			res1.append(all(res2))
		return any(res1)

# validate size
def size_clearance(size):
	max_size1 = 100 if max_size == 10 else max_size
	res = False
	value = float(re.split('\s', size.replace(',',''))[0])
	value *= 0.001 if 'M' in size else 1
	if min_size <= value <= max_size1:
		res = True
	return res

def verify(name,size):
	if included(name, [query_key.replace('.',' ')]):
		result = True
		if name != None:
			if not included(name, quality_allow) or included(name, quality_deny):
				result = False
		if size != None:
			if not size_clearance(size):
				result = False
	else:
		result = False
	return result

# clean_html
def clean_html(data):
	lines = re.findall('<!--(.*?)-->',data)
	for line in lines:
		data = data.replace(line,'')
	return data

# find the name in different language
def translator(imdb_id,language):
	import unicodedata
	url_themoviedb = "http://api.themoviedb.org/3/find/%s?api_key=8d0e4dca86c779f4157fc2c469c372ca&language=%s&external_source=imdb_id" % (imdb_id, language)
	response = provider.GET(url_themoviedb)
	if response != (None, None):
		movie = provider.parse_json(response.data)
		title0 = movie['movie_results'][0]['title'].replace(u'\xf1','*')
		title_normalize = unicodedata.normalize('NFKD', title0)
		title = title_normalize.encode('ascii','ignore').replace(':', '')
		title = title.decode('utf-8').replace('*',u'\xf1').encode('utf-8')
	else:
		title = 'Pas de communication avec le themoviedb.org' 
	return title

def clean(title):
	title = title.replace('s h i e l d','s.h.i.e.l.d')
	title = title.replace(' s ','s ')
	return title
#*******************************END common functions ****************************************

#movie_allow, movie_deny = movie_filtering()
TV_allow, TV_deny = TV_filtering()
	
# using function from Steeve to add Provider's name			
def extract_torrents(data):
	try:
		name = re.findall(r'/.page=view&#..;tid=(.*?)>(.*?)</a></td>',data) # find all names
		size = re.findall(r'<td class="tlistsize">(.*?)</td>',data) # find all sizes
		provider.log.info('Accepted Keywords: ' + str(quality_allow))
		provider.log.info('Blocked Keywords: ' + str(quality_deny))
		provider.log.info('min Size: ' + str(min_size) + ' GB')
		provider.log.info('max Size: ' + str(max_size)  + ' GB' if max_size != 10 else 'max Size: MAX')
		cm = 0
		for cm, torrent in enumerate(re.findall(r'/.page=download&#..;tid=(.*?)"', data)):
			#find name in the torrent
			if re.search(r'Searching torrents',data) is not None:
				if included(name[cm][1], quality_allow) and not included(name[cm][1], quality_deny) and size_clearance(size[cm]):
					yield { "name": name[cm][1] + ' - ' + size[cm] + ' - ' + name_provider,"uri": url + '/?page=download&tid=' + torrent}
				else:
					provider.log.warning(name + ' ***Blocked File by Keyword, Name or Size***')
				if (cm == max_magnets): #limit magnets
					break
			else:
				#Just one torrent
				name = re.search(r'"viewtorrentname">(.*?)<', data).group(1) + ' - ' + name_provider
				yield { "name": name,"uri": url + '?page=download&tid=' + torrent}
				break
	except:
		provider.log.error('>>>>>>>ERROR parsing data<<<<<<<')
	
def search(query):
	global query_key
	query_key = query # to do filtering by name
	query+= ' ' + extra
	if time_noti > 0 : provider.notify(message="Searching: " + query.title() + '...', header=None, time=time_noti, image=icon)
	url_search = "%s/?page=search&cats=%s&term=%s&sort=2" % (url,category,provider.quote_plus(query))
	provider.log.info(url_search)
	response = provider.GET(url_search)
	if response == (None, None):
		provider.log.error('404 Page not found')
		return []
	else:
		return extract_torrents(response.data)

def search_movie(info):
	return []

def search_episode(info):
	global quality_allow, quality_deny, min_size, max_size
	quality_allow = TV_allow
	quality_deny = TV_deny
	min_size = TV_min_size
	max_size = TV_max_size
	query = clean(info['title']) + ' %02d' % info['absolute_number'] 
	return search(query)

# This registers your module for use
provider.register(search, search_movie, search_episode)