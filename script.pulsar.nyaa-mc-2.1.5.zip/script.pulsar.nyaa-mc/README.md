Introduction
===================
Nyaa pulsar 0.2 provider, using settings
